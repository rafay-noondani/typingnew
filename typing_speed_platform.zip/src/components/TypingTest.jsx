import React, { useState, useEffect } from 'react';

export default function TypingTest() {
  const [text] = useState("The quick brown fox jumps over the lazy dog.");
  const [input, setInput] = useState("");
  const [startTime, setStartTime] = useState(null);
  const [wpm, setWpm] = useState(0);

  useEffect(() => {
    if (input.length === 1 && !startTime) {
      setStartTime(Date.now());
    }
    if (input.length === text.length && startTime) {
      const duration = (Date.now() - startTime) / 1000 / 60;
      const words = text.split(" ").length;
      setWpm(Math.round(words / duration));
    }
  }, [input]);

  return (
    <div className="max-w-2xl mx-auto p-4 bg-white shadow rounded">
      <h2 className="text-2xl font-bold mb-4">Typing Test</h2>
      <p className="mb-4">{text}</p>
      <textarea
        className="w-full p-2 border rounded"
        rows="4"
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      {wpm > 0 && <p className="mt-4 font-bold">Your WPM: {wpm}</p>}
    </div>
  );
}