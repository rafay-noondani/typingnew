import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import TypingTest from '../components/TypingTest';
import Lessons from '../components/Lessons';
import Practice from '../components/Practice';
import Games from '../components/Games';
import Certification from '../components/Certification';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-900">
      <nav className="bg-blue-600 text-white p-4 flex justify-between">
        <h1 className="font-bold text-xl">TypeMaster</h1>
        <div className="flex gap-4">
          <Link to="/">Test</Link>
          <Link to="/lessons">Lessons</Link>
          <Link to="/practice">Practice</Link>
          <Link to="/games">Games</Link>
          <Link to="/certification">Certification</Link>
        </div>
      </nav>
      <main className="p-4">
        <Routes>
          <Route path="/" element={<TypingTest />} />
          <Route path="/lessons" element={<Lessons />} />
          <Route path="/practice" element={<Practice />} />
          <Route path="/games" element={<Games />} />
          <Route path="/certification" element={<Certification />} />
        </Routes>
      </main>
    </div>
  );
}